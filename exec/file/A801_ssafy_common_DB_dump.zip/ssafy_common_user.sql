-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafy_common
-- ------------------------------------------------------
-- Server version	5.7.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(45) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `user_nickname` varchar(45) DEFAULT NULL,
  `user_password` varchar(64) NOT NULL,
  `user_phone` varchar(45) NOT NULL,
  `user_joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_delete_flag` int(11) NOT NULL DEFAULT '0',
  `user_alert_flag` int(11) NOT NULL DEFAULT '0',
  `user_activated` int(11) DEFAULT NULL,
  `user_is_social_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('admin@gmail.com','관리자','관리자','$2a$10$8.PN6TaQNjAf4afNkFv9GOV7ur8qyMz4MtcsS1jO87WLhYBbitTdi','01011112222','2023-02-14 03:15:31',0,0,0,0),('heejeong@gmail.com','엄희정',NULL,'$2a$10$fB2i3hQdlVFtKR.i8LxIH.l/TL9ewr0b7qwgdiVV.kV4ysItS.AfK','01098756148','2023-02-14 03:15:31',0,3,0,0),('heejun@gmail.com','전희준',NULL,'$2a$10$5L9R1SDLkm4aXzqEeBm67egxdf4fAzCLNYf/OqO7CEP0ZzwP0FDWm','01045101354','2023-02-14 03:15:31',0,2,0,0),('hihej@naver.com','카카오희정','카카오히정','$2a$10$UfzE03GGZ9GqxmtGEHmXZOXTDShy9oLQFi3KhoSky3hXW7QX0zOD6','01011112222','2023-02-14 04:12:32',0,1,0,0),('leeseong@gmail.com','이승진',NULL,'$2a$10$UvLcJdyMaDZLC3b3McOVFeddPn9A4ig9Hw.EcYVozTXsssrIec8yy','01045981354','2023-02-14 03:15:31',0,2,0,0),('mingyu@gmail.com','김민규','밍규','$2a$10$8.PN6TaQNjAf4afNkFv9GOV7ur8qyMz4MtcsS1jO87WLhYBbitTdi','01018945678','2023-02-14 03:15:31',0,0,0,0),('ssafy@gmail.com','김싸피','까비주인','$2a$10$8.PN6TaQNjAf4afNkFv9GOV7ur8qyMz4MtcsS1jO87WLhYBbitTdi','01011112222','2023-02-14 03:15:31',0,0,0,0),('woojin@gmail.com','이우진','우진','$2a$10$8.PN6TaQNjAf4afNkFv9GOV7ur8qyMz4MtcsS1jO87WLhYBbitTdi','01014795482','2023-02-14 03:15:31',0,0,0,0),('zjstjf@gmail.com','컨설',NULL,'$2a$10$iV6CHTufknnfR2BfVuaexOcsWdU2OgyVO8XI0psYxo9lOXA3mvFPu','01011112222','2023-02-14 03:52:59',1,1,0,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 14:11:53
