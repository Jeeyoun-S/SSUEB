-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafy_common
-- ------------------------------------------------------
-- Server version	5.7.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) NOT NULL,
  `user_nickname` varchar(45) DEFAULT NULL,
  `board_title` varchar(100) NOT NULL,
  `board_content` varchar(500) NOT NULL,
  `board_writetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `board_heartnum` int(11) DEFAULT NULL,
  `board_views` int(11) DEFAULT NULL,
  `board_flag` tinyint(4) DEFAULT NULL,
  `board_file` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,'heejun@gmail.com','전희준','토끼가 강한 이유를 아십니까?','\"깡\"도 있고 \"총\"도 있기 때문이지','2023-02-14 07:43:28',700,602,1,NULL),(2,'hihej@naver.com','엄희정','How to 고양이 인테리어!','가정집에서 손쉽게 할 수 있는 고양이를 위한 인테리어 입니다~','2023-02-06 02:43:28',210,600,1,NULL),(3,'leeseong@gmail.com','이승진','강아지 양치하는 방법','강아지 입냄새 박멸을 위한 양치법 입니당','2023-02-07 02:43:28',120,301,1,NULL),(4,'mingyu@gmail.com','밍규','가구가 남아나질 않아요..ㅠ','저희 집 댕댕이가 이갈이 시즌인지 가구를 가만두지 않습니다ㅠㅠ','2023-02-08 06:43:28',80,426,2,NULL),(5,'woojin@gmail.com','우진','이럴거면 일본을 갔습니다','최근 시바견을 분양받았는데..아..이럴거면 일본을 갔습니다ㅠ','2023-02-09 03:43:28',159,251,2,NULL),(6,'woojin@gmail.com','우진','나오면 안대는 게시글','좋아요 수 가장 낮음','2023-02-09 03:43:28',10,252,2,NULL),(7,'admin@gmail.com','관리자','[SSUEB] 2023년부터 고객센터 운영시간이 변경됩니다.','2023년부터 고객센터 업무 및 점심 시간대가 아래와 같이 변경됩니다.','2022-12-01 07:43:28',10,1,0,NULL),(8,'admin@gmail.com','관리자','[SSUEB] 12월 겨울맞이 이벤트','안녕하세요. 반려자님, SSEUB입니다:) 활기찬 겨울을 위해 이벤트를 진행하오니 많은 참여 부탁드립니다. ^^','2022-12-10 07:43:28',10,0,0,NULL),(9,'admin@gmail.com','관리자','[SSUEB]홈페이지 상담 신청하기 이벤트 \"01월 당첨자 발표\"','안녕하세요. 반려자님, SSUEB입니다:) 상담 신청만 해도 자동 응모 이벤트 참여해 주셔서 감사드립니다! 모두 모두 축하드리며, 순차적으로 개별 연락드리겠습니다.^^','2023-02-07 07:43:28',10,0,0,NULL);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 14:11:54
