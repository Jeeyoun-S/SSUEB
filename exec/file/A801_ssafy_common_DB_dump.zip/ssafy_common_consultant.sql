-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssafy_common
-- ------------------------------------------------------
-- Server version	5.7.35-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consultant`
--

DROP TABLE IF EXISTS `consultant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultant` (
  `id` varchar(45) NOT NULL,
  `consultant_pet_type` varchar(10) NOT NULL,
  `consultant_intro` varchar(300) DEFAULT NULL,
  `consultant_rate` double NOT NULL,
  `consultant_profile` varchar(100) DEFAULT NULL,
  `consultant_license_number` varchar(65) NOT NULL,
  `consultant_license_copy_image` varchar(100) NOT NULL,
  `consultant_reservation_count` int(11) DEFAULT NULL,
  `consultant_certified` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_consulant_user1_idx` (`id`),
  CONSTRAINT `fk_consulant_user1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultant`
--

LOCK TABLES `consultant` WRITE;
/*!40000 ALTER TABLE `consultant` DISABLE KEYS */;
INSERT INTO `consultant` VALUES ('heejeong@gmail.com','111001','안녕하세요~ 엄희정 전문가 입니다!',4,'68e236b4-6ee2-4c3f-8a49-136a42688553.png','123649845','53df0093-3c8b-4cd9-bf8e-0bca725db935.png',0,1),('heejun@gmail.com','111100','전희준 전문가 >< ><',4.5,'c7ed23c0-bfc9-485b-9ec8-6465bbdc618e.png','1009586987','53df0093-3c8b-4cd9-bf8e-0bca725db935.png',0,0),('leeseong@gmail.com','111000','이승진 전문가 입니다.',2.5,NULL,'1001516987','53df0093-3c8b-4cd9-bf8e-0bca725db935.png',0,1),('zjstjf@gmail.com','111000',NULL,0,NULL,'1111','a34a6d8e-915b-4227-9c60-59889f211bae.png',0,0);
/*!40000 ALTER TABLE `consultant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 14:11:53
